var searchData=
[
  ['keyboardkey_2840',['KeyboardKey',['../structtgui_1_1_event.html#a647c4342d425d6f03185126fc6eb5cd9',1,'tgui::Event']]],
  ['keymodifier_2841',['KeyModifier',['../structtgui_1_1_event.html#a37932d1570a768aafff139c38e9734c5',1,'tgui::Event']]]
];
