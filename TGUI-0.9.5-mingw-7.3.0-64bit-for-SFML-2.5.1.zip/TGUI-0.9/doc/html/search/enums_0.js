var searchData=
[
  ['alignment_2835',['Alignment',['../classtgui_1_1_edit_box.html#a3bdf669c969f3002777f84ef6bcc9393',1,'tgui::EditBox::Alignment()'],['../classtgui_1_1_grid.html#a862e75cc54ce2fff46c9590db7f6b5e9',1,'tgui::Grid::Alignment()']]]
];
