var searchData=
[
  ['v_1437',['V',['../structtgui_1_1_event.html#a647c4342d425d6f03185126fc6eb5cd9a5206560a306a2e085a437fd258eb57ce',1,'tgui::Event']]],
  ['validator_1438',['Validator',['../structtgui_1_1_edit_box_1_1_validator.html',1,'tgui::EditBox']]],
  ['variant_1439',['Variant',['../classtgui_1_1_variant.html',1,'tgui::Variant&lt; Types &gt;'],['../classtgui_1_1_variant.html#a40229ceafea7d43b22ef663079595b4c',1,'tgui::Variant::Variant()'],['../classtgui_1_1_variant.html#ace86a7b2587bdc7b8c85dfe60cb7b2f2',1,'tgui::Variant::Variant(const T &amp;value)']]],
  ['variant_3c_20tgui_3a_3astring_2c_20tgui_3a_3afont_2c_20tgui_3a_3acolor_2c_20tgui_3a_3aoutline_2c_20bool_2c_20float_2c_20tgui_3a_3atexture_2c_20tgui_3a_3atextstyles_2c_20std_3a_3ashared_5fptr_3c_20tgui_3a_3arendererdata_20_3e_20_3e_1440',['Variant&lt; tgui::String, tgui::Font, tgui::Color, tgui::Outline, bool, float, tgui::Texture, tgui::TextStyles, std::shared_ptr&lt; tgui::RendererData &gt; &gt;',['../classtgui_1_1_variant.html',1,'tgui']]],
  ['vector2_1441',['Vector2',['../classtgui_1_1_vector2.html',1,'tgui::Vector2&lt; T &gt;'],['../classtgui_1_1_vector2.html#af06f8645c8b4a200ab93576c402e7f3e',1,'tgui::Vector2::Vector2()'],['../classtgui_1_1_vector2.html#a882fde3868463724feee4a15b946d09c',1,'tgui::Vector2::Vector2(T xValue, T yValue)'],['../classtgui_1_1_vector2.html#afd764cde6b56bd75a65031da14e37e9c',1,'tgui::Vector2::Vector2(const Vector2&lt; U &gt; &amp;vec)'],['../classtgui_1_1_vector2.html#acd425de5f6f14e93ac7a4e46f65c51c3',1,'tgui::Vector2::Vector2(const sf::Vector2&lt; T &gt; &amp;vec)'],['../classtgui_1_1_vector2.html#af2930c45bb64a565e6791b893fc89457',1,'tgui::Vector2::Vector2(const char *str)'],['../classtgui_1_1_vector2.html#a8cf550078894eb9fb19bc183f821fe75',1,'tgui::Vector2::Vector2(String str)']]],
  ['vector2_3c_20float_20_3e_1442',['Vector2&lt; float &gt;',['../classtgui_1_1_vector2.html',1,'tgui']]],
  ['vector2_3c_20int_20_3e_1443',['Vector2&lt; int &gt;',['../classtgui_1_1_vector2.html',1,'tgui']]],
  ['vector2_3c_20std_3a_3asize_5ft_20_3e_1444',['Vector2&lt; std::size_t &gt;',['../classtgui_1_1_vector2.html',1,'tgui']]],
  ['vector2_3c_20unsigned_20int_20_3e_1445',['Vector2&lt; unsigned int &gt;',['../classtgui_1_1_vector2.html',1,'tgui']]],
  ['vertex_1446',['Vertex',['../structtgui_1_1_vertex.html',1,'tgui']]],
  ['vertical_1447',['Vertical',['../classtgui_1_1_sprite.html#a3ebf7132d60f5c6f4ca0c3ebd60ea9f8a06ce2a25e5d12c166a36f654dbea6012',1,'tgui::Sprite']]],
  ['verticalalignment_1448',['VerticalAlignment',['../classtgui_1_1_label.html#a2974ef71da25253342a8b3660b6d094c',1,'tgui::Label']]],
  ['verticallayout_1449',['VerticalLayout',['../classtgui_1_1_vertical_layout.html',1,'tgui']]]
];
