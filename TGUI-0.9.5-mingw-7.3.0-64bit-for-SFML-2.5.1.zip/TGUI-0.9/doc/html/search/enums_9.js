var searchData=
[
  ['scalingtype_2845',['ScalingType',['../classtgui_1_1_sprite.html#a3ebf7132d60f5c6f4ca0c3ebd60ea9f8',1,'tgui::Sprite']]],
  ['showeffecttype_2846',['ShowEffectType',['../namespacetgui.html#a21282b64e97068d726c1ba6b8fe17cf2',1,'tgui']]]
];
