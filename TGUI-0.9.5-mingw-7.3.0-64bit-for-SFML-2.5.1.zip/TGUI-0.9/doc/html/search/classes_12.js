var searchData=
[
  ['validator_1645',['Validator',['../structtgui_1_1_edit_box_1_1_validator.html',1,'tgui::EditBox']]],
  ['variant_1646',['Variant',['../classtgui_1_1_variant.html',1,'tgui']]],
  ['variant_3c_20tgui_3a_3astring_2c_20tgui_3a_3afont_2c_20tgui_3a_3acolor_2c_20tgui_3a_3aoutline_2c_20bool_2c_20float_2c_20tgui_3a_3atexture_2c_20tgui_3a_3atextstyles_2c_20std_3a_3ashared_5fptr_3c_20tgui_3a_3arendererdata_20_3e_20_3e_1647',['Variant&lt; tgui::String, tgui::Font, tgui::Color, tgui::Outline, bool, float, tgui::Texture, tgui::TextStyles, std::shared_ptr&lt; tgui::RendererData &gt; &gt;',['../classtgui_1_1_variant.html',1,'tgui']]],
  ['vector2_1648',['Vector2',['../classtgui_1_1_vector2.html',1,'tgui']]],
  ['vector2_3c_20float_20_3e_1649',['Vector2&lt; float &gt;',['../classtgui_1_1_vector2.html',1,'tgui']]],
  ['vector2_3c_20int_20_3e_1650',['Vector2&lt; int &gt;',['../classtgui_1_1_vector2.html',1,'tgui']]],
  ['vector2_3c_20std_3a_3asize_5ft_20_3e_1651',['Vector2&lt; std::size_t &gt;',['../classtgui_1_1_vector2.html',1,'tgui']]],
  ['vector2_3c_20unsigned_20int_20_3e_1652',['Vector2&lt; unsigned int &gt;',['../classtgui_1_1_vector2.html',1,'tgui']]],
  ['vertex_1653',['Vertex',['../structtgui_1_1_vertex.html',1,'tgui']]],
  ['verticallayout_1654',['VerticalLayout',['../classtgui_1_1_vertical_layout.html',1,'tgui']]]
];
