var searchData=
[
  ['operation_2843',['Operation',['../classtgui_1_1_layout.html#a35bfb195a1f1e6fd4ed82b0568feb81b',1,'tgui::Layout']]]
];
